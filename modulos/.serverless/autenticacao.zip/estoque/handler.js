'use strict';
const AWS = require('aws-sdk');
const jwt = require("jsonwebtoken");
const sql = require("mssql");

const USUARIOS_TABLE = process.env.USUARIOS_TABLE;
const AWS_DEPLOY_REGION = process.env.AWS_DEPLOY_REGION;
const JWT_ENCRYPTION_CODE = process.env.JWT_ENCRYPTION_CODE;
const connStr = process.env.SQLCONNECTIONSTRING;


function execSQLQuery(sqlQry, res){
  GLOBAL.conn.request()
             .query(sqlQry)
             .then(result => res.json(result.recordset))
             .catch(err => res.json(err));
}

module.exports.estoqueProduto = async (event, context) => {

  let idProduto = event.pathParameters.id;
  console.log(idProduto);
  //idProduto = idProduto.replace('\'', '\'\'');
  idProduto = idProduto.replace(/'/g,'\'\'');
  console.log(idProduto);
  sql.close();
  return await new Promise((resolve, reject) => {
    sql.connect(connStr)
    .then(conn => {
      var request = new sql.Request(conn);
      let queryString = `proc_BuscaEstoqueProduto '${idProduto}'`;
      console.log(queryString);
      return request.query(`proc_BuscaEstoqueProduto '${idProduto}'`);
    })
    .then(result => {
      console.log("resultados...");
      resolve({ statusCode: 200, headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true, 
      },  body: JSON.stringify(result.recordset)});
      sql.close();
    })
    .catch(err => {
      console.log("erro! " + err);
      reject(err);
    });
  });

  /*
  let _parsed;// = value;
  try {
    _parsed = JSON.parse(event.body);
  } catch (err) {
    console.error(`Could not parse requested JSON ${value}: ${err.stack}`);
    throw err;
  }  
  const id = _parsed.id;
  console.log(id);
  var key = { "id": id };
  const params = {
    Key: key, 
    TableName: USUARIOS_TABLE
  };

  console.log("Attempting a conditional delete...");
  return await new Promise((resolve, reject) => {
    dynamoDb.delete(params, (error, data) => {
      if (error) {
        console.error("Unable to delete item. Error JSON:" + JSON.stringify(error, null, 2));
        resolve({
          statusCode: 400,
          body: JSON.stringify({error:`Could not delete user: ${error.stack}`})
        });
  
      } else {
        resolve({ statusCode: 200});
      };
    });
  });
  */
  
}
